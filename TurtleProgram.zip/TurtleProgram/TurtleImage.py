# Displays two turtle images on top of one another with masked image.
# @author Taulant Xhakli
# @version 1.0

from PIL import Image, ImageFont, ImageDraw, ImageFilter

im1 = Image.open('turtle1.jpg')
im2 = Image.open('turtle2.jpg')

mask_im = Image.new("L", im2.size, 0)
draw = ImageDraw.Draw(mask_im)
draw.ellipse((100, 40, 450, 300), fill=255)
back_im = im1.copy()
back_im.paste(im2, (0, 0), mask_im)
mask_im_blur = mask_im.filter(ImageFilter.GaussianBlur(10))
back_im = im1.copy()
back_im.paste(im2, (0, 0), mask_im_blur)

back_im.save('circle_blur.jpg', quality=95)

idraw=ImageDraw.Draw(back_im)
myFont = ImageFont.truetype("Verdana.ttf",50)
idraw.text((700,50), "Turtle\nTestudines", font = myFont)

back_im.show()
